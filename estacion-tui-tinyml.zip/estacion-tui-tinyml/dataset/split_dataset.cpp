/**
 * @file split_dataset.cpp
 * @brief Organización de dataset por sesiones independientes para TinyML / FOMO.
 * Compilación: g++ -std=c++17 split_dataset.cpp -o split_dataset
 * Uso: ./split_dataset manifest.csv ./dataset_out
 */

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <random>
#include <filesystem>
#include <iomanip>

namespace fs = std::filesystem;

struct Record {
    std::string path;
    std::string session;
    std::string className;
    std::string boxesJson;
    std::string sha256;
    std::string split;
};

std::vector<std::string> parseCsvLine(const std::string& line) {
    std::vector<std::string> fields;
    std::string current;
    bool inQuotes = false;
    for (size_t i = 0; i < line.size(); ++i) {
        char c = line[i];
        if (c == '"') {
            if (inQuotes && i + 1 < line.size() && line[i + 1] == '"') {
                current += '"';
                ++i;
            } else {
                inQuotes = !inQuotes;
            }
        } else if (c == ',' && !inQuotes) {
            fields.push_back(current);
            current.clear();
        } else {
            current += c;
        }
    }
    fields.push_back(current);
    return fields;
}

std::string computePseudoHash(const fs::path& filePath) {
    std::ifstream file(filePath, std::ios::binary);
    if (!file) return "0000000000000000";
    uint64_t hash = 14695981039346656037ULL;
    char buffer[4096];
    while (file.read(buffer, sizeof(buffer)) || file.gcount() > 0) {
        for (std::streamsize i = 0; i < file.gcount(); ++i) {
            hash ^= static_cast<uint8_t>(buffer[i]);
            hash *= 1099511628211ULL;
        }
    }
    std::stringstream ss;
    ss << std::hex << std::setw(16) << std::setfill('0') << hash;
    return ss.str();
}

int main(int argc, char* argv[]) {
    if (argc < 3) {
        std::cerr << "Uso: " << argv[0] << " <manifest.csv> <directorio_salida>\n";
        return 1;
    }

    fs::path manifestPath = argv[1];
    fs::path outputDir = argv[2];
    fs::path baseDir = manifestPath.parent_path();

    std::ifstream infile(manifestPath);
    if (!infile.is_open()) {
        std::cerr << "Error: No se pudo abrir " << manifestPath << "\n";
        return 1;
    }

    std::string headerLine;
    if (!std::getline(infile, headerLine)) {
        std::cerr << "Error: Archivo vacio.\n";
        return 1;
    }

    std::vector<Record> records;
    std::set<std::string> uniqueSessions;
    std::string line;

    while (std::getline(infile, line)) {
        if (line.empty()) continue;
        auto cols = parseCsvLine(line);
        if (cols.size() < 4) continue;

        Record r;
        r.path = cols[0];
        r.session = cols[1];
        r.className = cols[2];
        r.boxesJson = cols[3];

        fs::path fullImgPath = baseDir / r.path;
        if (!fs::exists(fullImgPath)) {
            std::cerr << "Advertencia: Imagen no encontrada: " << fullImgPath << "\n";
            continue;
        }

        r.sha256 = computePseudoHash(fullImgPath);
        records.push_back(r);
        uniqueSessions.insert(r.session);
    }

    if (uniqueSessions.empty()) {
        std::cerr << "Error: No se registraron sesiones validas.\n";
        return 1;
    }

    std::vector<std::string> sessionList(uniqueSessions.begin(), uniqueSessions.end());
    std::mt19937 rng(42);
    std::shuffle(sessionList.begin(), sessionList.end(), rng);

    size_t n = sessionList.size();
    size_t trainLimit = static_cast<size_t>(n * 0.70);
    size_t valLimit = static_cast<size_t>(n * 0.85);

    std::map<std::string, std::string> sessionSplit;
    for (size_t i = 0; i < n; ++i) {
        if (i < trainLimit) sessionSplit[sessionList[i]] = "train";
        else if (i < valLimit) sessionSplit[sessionList[i]] = "validation";
        else sessionSplit[sessionList[i]] = "test";
    }

    // Si hay muy pocas sesiones de muestra, asignar al menos a train
    for (auto& s : sessionList) {
        if (sessionSplit[s].empty()) sessionSplit[s] = "train";
    }

    fs::create_directories(outputDir / "train");
    fs::create_directories(outputDir / "validation");
    fs::create_directories(outputDir / "test");

    std::map<std::string, std::vector<std::pair<std::string, std::string>>> labelsPerSplit;
    std::map<std::string, int> countPerSplit = {{"train", 0}, {"validation", 0}, {"test", 0}};

    for (auto& r : records) {
        r.split = sessionSplit[r.session];
        countPerSplit[r.split]++;

        fs::path srcPath = baseDir / r.path;
        std::string destFileName = r.sha256 + srcPath.extension().string();
        fs::path destPath = outputDir / r.split / destFileName;

        try {
            fs::copy_file(srcPath, destPath, fs::copy_options::overwrite_existing);
        } catch (const std::exception& e) {
            std::cerr << "Error al copiar: " << e.what() << "\n";
        }

        labelsPerSplit[r.split].push_back({destFileName, r.boxesJson});
    }

    for (const std::string& splitName : {"train", "validation", "test"}) {
        fs::path labelFile = outputDir / splitName / "bounding_boxes.labels";
        std::ofstream outLabels(labelFile);
        outLabels << "{\n  \"version\": 1,\n  \"type\": \"bounding-box-labels\",\n  \"boundingBoxes\": {\n";
        const auto& list = labelsPerSplit[splitName];
        for (size_t i = 0; i < list.size(); ++i) {
            outLabels << "    \"" << list[i].first << "\": " << list[i].second;
            if (i + 1 < list.size()) outLabels << ",";
            outLabels << "\n";
        }
        outLabels << "  }\n}\n";
    }

    std::ofstream outManifest(outputDir / "split_manifest.csv");
    outManifest << "path,session,class_name,sha256,split\n";
    for (const auto& r : records) {
        outManifest << r.path << "," << r.session << "," << r.className << ","
                    << r.sha256 << "," << r.split << "\n";
    }

    std::cout << "\n=== Particion completada con exito ===\n";
    std::cout << "Train:      " << countPerSplit["train"] << " imagenes\n";
    std::cout << "Validation: " << countPerSplit["validation"] << " imagenes\n";
    std::cout << "Test:       " << countPerSplit["test"] << " imagenes\n";
    std::cout << "Guardado en: " << outputDir << "\n";

    return 0;
}