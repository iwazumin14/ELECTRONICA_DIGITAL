ESTACIÓN TUI - CÓDIGO FLUTTER SEPARADO
======================================

ESTRUCTURA
----------
lib/main.dart
    Interfaz funcional: resumen, historial, búsqueda BLE, descarga de registros,
    configuración MQTT y envío a Cloud.

lib/data/event_store.dart
    SQLite. Valida eventos reales, evita duplicados por event_id y conserva
    el estado pendiente/confirmado.

lib/services/ble_reader.dart
    Busca el servicio BLE del firmware, habilita notificaciones, envía GET:n,
    reconstruye JSONL en fragmentos de 20 bytes y guarda cada evento.

lib/services/cloud_sync.dart
    MQTT/TLS en el puerto 8883, publicación QoS 1 y ACK de aplicación.
    Solo marca el evento como sincronizado cuando recibe stored=true.

lib/config/cloud_settings.dart
    Guarda host, usuario, contraseña y CA PEM con flutter_secure_storage.

pubspec.yaml
    Dependencias Flutter.

android_config/AndroidManifest_permissions.xml
    Permisos que debes incorporar al AndroidManifest generado por Flutter.

INSTALACIÓN
-----------
1. Instala Flutter y crea la base del proyecto:
       flutter create tui_estacion

2. Copia el contenido de esta carpeta sobre el proyecto creado:
       lib/
       pubspec.yaml

3. Ejecuta:
       flutter pub get

4. Abre android/app/src/main/AndroidManifest.xml y añade las declaraciones
   de android_config/AndroidManifest_permissions.xml dentro de <manifest>.
   No reemplaces el resto del manifiesto.

5. Ejecuta:
       flutter analyze
       flutter run

CONTRATO CON EL FIRMWARE DEL DOCUMENTO
--------------------------------------
Servicio BLE: 4fa1c000-18a3-4a7e-b05d-1b2073d31cce
DATA notify:  4fa1c001-18a3-4a7e-b05d-1b2073d31cce
CMD write:    4fa1c002-18a3-4a7e-b05d-1b2073d31cce
Comando:      GET:<índice>
Datos:        JSONL terminado en salto de línea, fragmentos de 20 bytes.
Marcador fin: {"end":true}
MQTT eventos: tui/v1/<device_id>/events
MQTT ACK:     tui/v1/<device_id>/ack
Puerto MQTT:  8883/TLS

CONFIGURACIÓN CLOUD
-------------------
En la pestaña Dispositivo, configura el host, usuario y contraseña de Mosquitto.
Si el broker usa una CA privada, pega el certificado PEM de la CA en el campo
correspondiente. El certificado no está incluido porque el documento no aporta
un certificado real. No se desactiva la validación TLS.

LÍMITES Y VALIDACIONES PENDIENTES
---------------------------------
- El documento indica que Flutter, BLE y MQTT no se compilaron ni integraron
  completamente con las placas. Este código es una integración propuesta, no
  una prueba física ni una compilación certificada.
- Se requiere ejecutar flutter pub get, flutter analyze y flutter run en el
  entorno del equipo, resolver posibles cambios de API según la versión Flutter
  instalada y probar con la placa real.
- El firmware debe estar cargado con las UUID, características, comandos GET:n
  y formato JSONL descritos. La aplicación no corrige errores del firmware.
- Si SPIFFS no está disponible en el ESP32, el firmware no responde al GET y
  la aplicación acabará agotando el tiempo de espera BLE.
- Los registros se vuelven a descargar desde el índice 0 en cada sincronización.
  SQLite evita duplicados mediante event_id; el firmware actual no implementa
  borrado/ACK individual de registros en SPIFFS.
- El acceso a MQTT requiere credenciales válidas y certificado confiable.
  No se incluye broker, certificado, contraseña ni archivo de ACL.
- La app no implementa cuentas de usuario ni bonding BLE autenticado. La
  protección de credenciales Cloud se limita al almacenamiento seguro local.
- No se incluye vídeo, inferencia TinyML, audio, validación lingüística, ni
  control del dispositivo: esas tareas permanecen en el ESP32.
