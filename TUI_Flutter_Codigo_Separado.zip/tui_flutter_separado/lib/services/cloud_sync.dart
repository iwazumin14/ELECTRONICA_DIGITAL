import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:mqtt_client/mqtt_client.dart';
import 'package:mqtt_client/mqtt_server_client.dart';

import '../config/cloud_settings.dart';
import '../data/event_store.dart';

/// Publica eventos en MQTT QoS 1 y espera el ACK de aplicación del ingestor.
/// El evento solo pasa a synced=1 cuando el servidor responde stored=true.
class CloudSync {
  Future<int> upload(
    EventStore store,
    CloudSettings settings,
    String deviceId, {
    Duration ackTimeout = const Duration(seconds: 15),
  }) async {
    if (!settings.isComplete) {
      throw ArgumentError('La configuración MQTT está incompleta.');
    }
    if (!RegExp(r'^tui-[0-9a-f]{12}$').hasMatch(deviceId)) {
      throw ArgumentError.value(deviceId, 'deviceId', 'Identificador inválido.');
    }

    final clientId =
        'flutter-${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}';
    final client = MqttServerClient(settings.host.trim(), clientId)
      ..port = 8883
      ..secure = true
      ..keepAlivePeriod = 30
      ..setProtocolV311()
      ..logging(on: false)
      ..onBadCertificate = (_) => false;

    // Se parte de las CA raíz del sistema. Para Mosquitto con CA privada,
    // se añade el PEM que el administrador debe entregar al equipo.
    final securityContext = SecurityContext(withTrustedRoots: true);
    final caPem = settings.caPem.trim();
    if (caPem.isNotEmpty) {
      securityContext.setTrustedCertificatesBytes(
        Uint8List.fromList(utf8.encode(caPem)),
      );
    }
    client.securityContext = securityContext;

    StreamSubscription<List<MqttReceivedMessage<MqttMessage>>>? updatesSub;
    final waiters = <String, Completer<void>>{};
    final ackTopic = 'tui/v1/$deviceId/ack';
    final eventTopic = 'tui/v1/$deviceId/events';

    try {
      await client.connect(settings.username.trim(), settings.password);
      if (client.connectionStatus?.state != MqttConnectionState.connected) {
        throw StateError('El broker MQTT rechazó la conexión.');
      }

      final subscribed = Completer<void>();
      client.onSubscribed = (topic) {
        if (topic == ackTopic && !subscribed.isCompleted) {
          subscribed.complete();
        }
      };

      final updates = client.updates;
      if (updates == null) {
        throw StateError('El cliente MQTT no habilitó el flujo de respuestas.');
      }

      updatesSub = updates.listen((messages) {
        for (final received in messages) {
          try {
            final publish = received.payload as MqttPublishMessage;
            final raw = MqttPublishPayload.bytesToStringAsString(
              publish.payload.message,
            );
            final ack = jsonDecode(raw);
            if (ack is! Map<String, dynamic>) continue;
            if (ack['stored'] != true) continue;

            final eventId = ack['event_id'];
            if (eventId is! String) continue;

            final waiter = waiters[eventId];
            if (waiter != null && !waiter.isCompleted) {
              waiter.complete();
            }
          } catch (_) {
            // Los ACK malformados se ignoran; el evento queda pendiente.
          }
        }
      });

      client.subscribe(ackTopic, MqttQos.atLeastOnce);
      await subscribed.future.timeout(const Duration(seconds: 10));

      var uploaded = 0;
      final pendingRows = await store.pending(deviceId: deviceId);

      for (final row in pendingRows) {
        final eventId = row['id'] as String;
        final payload = row['payload'] as String;
        final event = jsonDecode(payload);

        if (event is! Map<String, dynamic> ||
            event['event_id'] != eventId ||
            event['device_id'] != deviceId ||
            event['demo'] != false) {
          throw FormatException('Evento local inconsistente: $eventId');
        }

        final waiter = Completer<void>();
        waiters[eventId] = waiter;

        final builder = MqttClientPayloadBuilder()..addString(payload);
        final bytes = builder.payload;
        if (bytes == null) {
          waiters.remove(eventId);
          throw StateError('No se pudo codificar el evento $eventId.');
        }

        try {
          client.publishMessage(
            eventTopic,
            MqttQos.atLeastOnce,
            bytes,
            retain: false,
          );

          // ACK de aplicación: el ingestor lo publica después de COMMIT.
          await waiter.future.timeout(ackTimeout);
          await store.ack(eventId);
          uploaded++;
        } finally {
          waiters.remove(eventId);
        }
      }

      return uploaded;
    } finally {
      for (final waiter in waiters.values) {
        if (!waiter.isCompleted) {
          waiter.completeError(StateError('Conexión MQTT finalizada.'));
        }
      }
      waiters.clear();
      await updatesSub?.cancel();
      client.disconnect();
    }
  }
}
