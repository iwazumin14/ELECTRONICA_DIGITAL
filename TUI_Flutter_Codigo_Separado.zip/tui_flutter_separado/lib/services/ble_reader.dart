import 'dart:async';
import 'dart:convert';

import 'package:flutter_blue_plus/flutter_blue_plus.dart';

import '../data/event_store.dart';

/// UUID definidos en el firmware del ESP32 DevKit, apartado BLE del T2.
const String tuiServiceUuid = '4fa1c000-18a3-4a7e-b05d-1b2073d31cce';
const String tuiDataUuid = '4fa1c001-18a3-4a7e-b05d-1b2073d31cce';
const String tuiCommandUuid = '4fa1c002-18a3-4a7e-b05d-1b2073d31cce';

class BleSyncResult {
  const BleSyncResult({
    required this.received,
    required this.inserted,
    required this.duplicates,
  });

  final int received;
  final int inserted;
  final int duplicates;
}

/// Busca el servicio TUI y descarga /events.jsonl mediante comandos GET:n.
/// El ESP32 envía cada línea JSONL por notificaciones de hasta 20 bytes.
class BleReader {
  Future<List<ScanResult>> scan({
    Duration scanDuration = const Duration(seconds: 8),
  }) async {
    final adapterState = await FlutterBluePlus.adapterState
        .where((state) => state == BluetoothAdapterState.on)
        .first
        .timeout(
          const Duration(seconds: 15),
          onTimeout: () => throw StateError(
            'Bluetooth está apagado o no está disponible en el teléfono.',
          ),
        );
    // La variable evita que el analizador considere ignorado el resultado.
    if (adapterState != BluetoothAdapterState.on) {
      throw StateError('Bluetooth no está encendido.');
    }

    await FlutterBluePlus.startScan(
      withServices: [Guid(tuiServiceUuid)],
      timeout: scanDuration,
    );

    await FlutterBluePlus.isScanning
        .where((isScanning) => !isScanning)
        .first
        .timeout(scanDuration + const Duration(seconds: 5));

    return FlutterBluePlus.lastScanResults;
  }

  Future<BleSyncResult> sync(
    BluetoothDevice device,
    EventStore store, {
    int maxRecords = 10000,
    Duration responseTimeout = const Duration(seconds: 15),
  }) async {
    StreamSubscription<List<int>>? notificationSubscription;
    BluetoothCharacteristic? dataCharacteristic;
    BluetoothCharacteristic? commandCharacteristic;

    final buffer = <int>[];
    Completer<Map<String, dynamic>>? currentResponse;
    var received = 0;
    var inserted = 0;
    var duplicates = 0;

    await device.connect(timeout: const Duration(seconds: 15));

    try {
      final services = await device.discoverServices();
      final service = services.firstWhere(
        (item) => item.uuid == Guid(tuiServiceUuid),
        orElse: () => throw StateError(
          'El dispositivo no expone el servicio BLE de la Estación TUI.',
        ),
      );

      dataCharacteristic = service.characteristics.firstWhere(
        (item) => item.uuid == Guid(tuiDataUuid),
        orElse: () => throw StateError('No se encontró la característica DATA.'),
      );
      commandCharacteristic = service.characteristics.firstWhere(
        (item) => item.uuid == Guid(tuiCommandUuid),
        orElse: () => throw StateError('No se encontró la característica CMD.'),
      );

      notificationSubscription = dataCharacteristic.onValueReceived.listen(
        (chunk) {
          final completer = currentResponse;
          if (completer == null || completer.isCompleted) return;

          buffer.addAll(chunk);
          if (buffer.length > 4096) {
            completer.completeError(
              StateError('La línea JSONL BLE superó 4096 bytes.'),
            );
            currentResponse = null;
            buffer.clear();
            return;
          }

          final newlineIndex = buffer.indexOf(10); // '\n'
          if (newlineIndex < 0) return;

          final line = buffer.sublist(0, newlineIndex);
          buffer.removeRange(0, newlineIndex + 1);

          try {
            final decoded = jsonDecode(utf8.decode(line));
            if (decoded is! Map<String, dynamic>) {
              throw const FormatException('La respuesta BLE no es un objeto JSON.');
            }
            completer.complete(decoded);
          } catch (error, stackTrace) {
            completer.completeError(error, stackTrace);
          } finally {
            currentResponse = null;
          }
        },
        onError: (Object error, StackTrace stackTrace) {
          final completer = currentResponse;
          if (completer != null && !completer.isCompleted) {
            completer.completeError(error, stackTrace);
          }
          currentResponse = null;
          buffer.clear();
        },
      );

      await dataCharacteristic.setNotifyValue(true);

      for (var index = 0; index < maxRecords; index++) {
        final completer = Completer<Map<String, dynamic>>();
        currentResponse = completer;
        buffer.clear();

        // El firmware procesa exactamente el comando ASCII GET:<índice>.
        await commandCharacteristic.write(
          utf8.encode('GET:$index'),
          withoutResponse: false,
        );

        final event = await completer.future.timeout(responseTimeout);
        currentResponse = null;

        if (event['end'] == true) {
          return BleSyncResult(
            received: received,
            inserted: inserted,
            duplicates: duplicates,
          );
        }

        final wasInserted = await store.put(event);
        received++;
        if (wasInserted) {
          inserted++;
        } else {
          duplicates++;
        }
      }

      throw StateError(
        'Se alcanzó el máximo de $maxRecords registros sin recibir el marcador end.',
      );
    } finally {
      currentResponse = null;
      await notificationSubscription?.cancel();
      if (dataCharacteristic != null) {
        try {
          await dataCharacteristic.setNotifyValue(false);
        } catch (_) {
          // La desconexión puede haber ocurrido antes de desactivar notify.
        }
      }
      await device.disconnect();
    }
  }
}
