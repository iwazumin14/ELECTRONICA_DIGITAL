import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class CloudSettings {
  const CloudSettings({
    required this.host,
    required this.username,
    required this.password,
    this.caPem = '',
  });

  final String host;
  final String username;
  final String password;

  /// Certificado PEM de la CA privada del broker. Vacío si el broker usa
  /// una CA pública que ya reconoce Android.
  final String caPem;

  bool get isComplete =>
      host.trim().isNotEmpty &&
      username.trim().isNotEmpty &&
      password.isNotEmpty;
}

class CloudSettingsStore {
  static const FlutterSecureStorage _storage = FlutterSecureStorage();

  static const _hostKey = 'tui_mqtt_host';
  static const _usernameKey = 'tui_mqtt_username';
  static const _passwordKey = 'tui_mqtt_password';
  static const _caKey = 'tui_mqtt_ca_pem';

  Future<CloudSettings?> load() async {
    final host = await _storage.read(key: _hostKey);
    final username = await _storage.read(key: _usernameKey);
    final password = await _storage.read(key: _passwordKey);
    final caPem = await _storage.read(key: _caKey) ?? '';

    if (host == null || username == null || password == null) return null;

    final settings = CloudSettings(
      host: host,
      username: username,
      password: password,
      caPem: caPem,
    );
    return settings.isComplete ? settings : null;
  }

  Future<void> save(CloudSettings settings) async {
    if (!settings.isComplete) {
      throw ArgumentError('Completa host, usuario y contraseña MQTT.');
    }

    await _storage.write(key: _hostKey, value: settings.host.trim());
    await _storage.write(key: _usernameKey, value: settings.username.trim());
    await _storage.write(key: _passwordKey, value: settings.password);
    await _storage.write(key: _caKey, value: settings.caPem.trim());
  }

  Future<void> clear() async {
    await _storage.delete(key: _hostKey);
    await _storage.delete(key: _usernameKey);
    await _storage.delete(key: _passwordKey);
    await _storage.delete(key: _caKey);
  }
}
