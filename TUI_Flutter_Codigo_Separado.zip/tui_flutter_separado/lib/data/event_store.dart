import 'dart:convert';

import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// Almacén local de eventos recibidos desde el ESP32 DevKit.
/// Solo admite eventos reales del firmware (demo == false).
class EventStore {
  static const String _databaseName = 'tui_estacion.db';
  static const int _databaseVersion = 1;

  Database? _database;

  Database get _db {
    final database = _database;
    if (database == null || !database.isOpen) {
      throw StateError('EventStore no está abierto. Ejecuta open() primero.');
    }
    return database;
  }

  Future<void> open() async {
    if (_database != null && _database!.isOpen) return;

    final databasePath = await getDatabasesPath();
    final fullPath = p.join(databasePath, _databaseName);

    _database = await openDatabase(
      fullPath,
      version: _databaseVersion,
      onCreate: (db, version) async {
        await db.execute('''
          CREATE TABLE events (
            id TEXT PRIMARY KEY,
            device_id TEXT NOT NULL,
            payload TEXT NOT NULL,
            synced INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
          )
        ''');
        await db.execute(
          'CREATE INDEX idx_events_synced ON events(synced)',
        );
        await db.execute(
          'CREATE INDEX idx_events_device ON events(device_id)',
        );
      },
      onUpgrade: (db, oldVersion, newVersion) async {
        // Reservado para migraciones futuras.
      },
    );
  }

  /// Inserta un evento si todavía no existe.
  /// Devuelve true si se insertó y false si ya estaba guardado.
  Future<bool> put(Map<String, dynamic> event) async {
    if (event['demo'] != false) {
      throw StateError('Se rechazó un registro demo o sin marca demo=false.');
    }

    final eventId = event['event_id'];
    final deviceId = event['device_id'];
    final schema = event['schema'];

    if (eventId is! String || eventId.isEmpty) {
      throw const FormatException('El evento no contiene event_id válido.');
    }
    if (deviceId is! String ||
        !RegExp(r'^tui-[0-9a-f]{12}$').hasMatch(deviceId)) {
      throw const FormatException('El evento contiene device_id inválido.');
    }
    if (!eventId.startsWith('$deviceId-')) {
      throw const FormatException('event_id no corresponde a device_id.');
    }
    if (schema != 1) {
      throw const FormatException('Versión de esquema de evento no admitida.');
    }

    final payload = jsonEncode(event);

    return _db.transaction((txn) async {
      final existing = await txn.query(
        'events',
        columns: ['payload'],
        where: 'id = ?',
        whereArgs: [eventId],
        limit: 1,
      );

      if (existing.isNotEmpty) {
        final previousPayload = existing.first['payload'] as String;
        if (previousPayload != payload) {
          throw StateError(
            'Se recibió el mismo event_id con contenido diferente: $eventId',
          );
        }
        return false;
      }

      await txn.insert('events', {
        'id': eventId,
        'device_id': deviceId,
        'payload': payload,
        'synced': 0,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      });
      return true;
    });
  }

  /// Registros aún no confirmados por el servidor.
  Future<List<Map<String, Object?>>> pending({String? deviceId}) async {
    return _db.query(
      'events',
      where: deviceId == null ? 'synced = 0' : 'synced = 0 AND device_id = ?',
      whereArgs: deviceId == null ? null : [deviceId],
      orderBy: 'rowid ASC',
    );
  }

  /// Marca como sincronizado solamente después del ACK de aplicación Cloud.
  Future<void> ack(String eventId) async {
    await _db.update(
      'events',
      {'synced': 1},
      where: 'id = ?',
      whereArgs: [eventId],
    );
  }

  Future<List<Map<String, dynamic>>> allEvents({int limit = 200}) async {
    final rows = await _db.query(
      'events',
      orderBy: 'rowid DESC',
      limit: limit,
    );

    return rows.map((row) {
      final event = Map<String, dynamic>.from(
        jsonDecode(row['payload'] as String) as Map,
      );
      event['_synced'] = row['synced'] == 1;
      event['_stored_at'] = row['created_at'];
      return event;
    }).toList();
  }

  Future<List<String>> deviceIds() async {
    final rows = await _db.rawQuery(
      'SELECT DISTINCT device_id FROM events ORDER BY device_id ASC',
    );
    return rows.map((row) => row['device_id'] as String).toList();
  }

  Future<Map<String, int>> stats() async {
    final total = Sqflite.firstIntValue(
          await _db.rawQuery('SELECT COUNT(*) FROM events'),
        ) ??
        0;
    final pendingCount = Sqflite.firstIntValue(
          await _db.rawQuery('SELECT COUNT(*) FROM events WHERE synced = 0'),
        ) ??
        0;

    return {
      'total': total,
      'pending': pendingCount,
      'synced': total - pendingCount,
    };
  }

  Future<void> close() async {
    final database = _database;
    _database = null;
    if (database != null && database.isOpen) {
      await database.close();
    }
  }
}
