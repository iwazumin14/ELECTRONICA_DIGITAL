import 'dart:io';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:permission_handler/permission_handler.dart';

import 'config/cloud_settings.dart';
import 'data/event_store.dart';
import 'services/ble_reader.dart';
import 'services/cloud_sync.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final eventStore = EventStore();
  await eventStore.open();

  runApp(TuiApp(
    eventStore: eventStore,
    cloudSettingsStore: CloudSettingsStore(),
  ));
}

class TuiApp extends StatelessWidget {
  const TuiApp({
    required this.eventStore,
    required this.cloudSettingsStore,
    super.key,
  });

  final EventStore eventStore;
  final CloudSettingsStore cloudSettingsStore;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Estación TUI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.teal),
        useMaterial3: true,
        scaffoldBackgroundColor: const Color(0xFFF5F7F8),
      ),
      home: HomePage(
        eventStore: eventStore,
        cloudSettingsStore: cloudSettingsStore,
      ),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({
    required this.eventStore,
    required this.cloudSettingsStore,
    super.key,
  });

  final EventStore eventStore;
  final CloudSettingsStore cloudSettingsStore;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final BleReader _bleReader = BleReader();
  final CloudSync _cloudSync = CloudSync();

  int _selectedPage = 0;
  bool _isScanning = false;
  bool _isSyncingBle = false;
  bool _isUploading = false;
  String? _operationMessage;
  String? _operationError;

  List<ScanResult> _scanResults = [];
  ScanResult? _selectedDevice;
  List<Map<String, dynamic>> _events = [];
  List<String> _deviceIds = [];
  Map<String, int> _stats = {'total': 0, 'pending': 0, 'synced': 0};
  CloudSettings? _cloudSettings;
  String? _cloudDeviceId;

  @override
  void initState() {
    super.initState();
    _refreshLocalData();
    _loadCloudSettings();
  }

  Future<void> _refreshLocalData() async {
    try {
      final results = await Future.wait([
        widget.eventStore.allEvents(limit: 200),
        widget.eventStore.deviceIds(),
        widget.eventStore.stats(),
      ]);
      if (!mounted) return;
      setState(() {
        _events = results[0] as List<Map<String, dynamic>>;
        _deviceIds = results[1] as List<String>;
        _stats = results[2] as Map<String, int>;
        if (_cloudDeviceId == null || !_deviceIds.contains(_cloudDeviceId)) {
          _cloudDeviceId = _deviceIds.isEmpty ? null : _deviceIds.first;
        }
      });
    } catch (error) {
      _showMessage('No se pudo leer SQLite: $error', isError: true);
    }
  }

  Future<void> _loadCloudSettings() async {
    try {
      final settings = await widget.cloudSettingsStore.load();
      if (!mounted) return;
      setState(() => _cloudSettings = settings);
    } catch (error) {
      _showMessage('No se pudo leer la configuración Cloud: $error', isError: true);
    }
  }

  Future<bool> _requestBluetoothPermissions() async {
    if (!Platform.isAndroid) return true;

    final androidInfo = await DeviceInfoPlugin().androidInfo;
    if (androidInfo.version.sdkInt >= 31) {
      final scan = await Permission.bluetoothScan.request();
      final connect = await Permission.bluetoothConnect.request();
      return scan.isGranted && connect.isGranted;
    }

    final location = await Permission.locationWhenInUse.request();
    return location.isGranted;
  }

  Future<void> _scanDevices() async {
    if (_isScanning || _isSyncingBle) return;

    setState(() {
      _isScanning = true;
      _operationError = null;
      _operationMessage = 'Buscando la Estación TUI por Bluetooth LE…';
      _scanResults = [];
      _selectedDevice = null;
    });

    try {
      final permitted = await _requestBluetoothPermissions();
      if (!permitted) {
        throw StateError(
          'Faltan permisos Bluetooth. Autorízalos en los ajustes de Android.',
        );
      }

      final results = await _bleReader.scan();
      final unique = <String, ScanResult>{};
      for (final result in results) {
        unique[result.device.remoteId.str] = result;
      }

      if (!mounted) return;
      setState(() {
        _scanResults = unique.values.toList();
        _operationMessage = _scanResults.isEmpty
            ? 'No se encontraron dispositivos con el servicio TUI.'
            : 'Se encontraron ${_scanResults.length} dispositivo(s).';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _operationError = error.toString();
        _operationMessage = null;
      });
    } finally {
      if (mounted) setState(() => _isScanning = false);
    }
  }

  Future<void> _syncSelectedDevice() async {
    final selected = _selectedDevice;
    if (selected == null || _isSyncingBle || _isScanning) return;

    setState(() {
      _isSyncingBle = true;
      _operationError = null;
      _operationMessage = 'Conectando y descargando registros…';
    });

    try {
      final result = await _bleReader.sync(selected.device, widget.eventStore);
      await _refreshLocalData();
      if (!mounted) return;
      setState(() {
        _operationMessage =
            'BLE terminado: ${result.received} recibidos, '
            '${result.inserted} nuevos y ${result.duplicates} duplicados ignorados.';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _operationError = error.toString();
        _operationMessage = null;
      });
    } finally {
      if (mounted) setState(() => _isSyncingBle = false);
    }
  }

  Future<void> _configureCloud() async {
    final previous = _cloudSettings;
    final hostController = TextEditingController(text: previous?.host ?? '');
    final usernameController = TextEditingController(
      text: previous?.username ?? '',
    );
    final passwordController = TextEditingController(
      text: previous?.password ?? '',
    );
    final caController = TextEditingController(text: previous?.caPem ?? '');

    final settings = await showDialog<CloudSettings>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Configuración MQTT segura'),
        content: SizedBox(
          width: 520,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: hostController,
                  decoration: const InputDecoration(
                    labelText: 'Host o IP del broker',
                    hintText: 'mqtt.midominio.edu',
                  ),
                  keyboardType: TextInputType.url,
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: usernameController,
                  decoration: const InputDecoration(labelText: 'Usuario MQTT'),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Contraseña MQTT',
                  ),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: caController,
                  minLines: 3,
                  maxLines: 7,
                  decoration: const InputDecoration(
                    labelText: 'Certificado CA en PEM (opcional)',
                    hintText: '-----BEGIN CERTIFICATE-----',
                    alignLabelWithHint: true,
                  ),
                ),
                const SizedBox(height: 8),
                const Text(
                  'Puerto TLS fijo: 8883. Pega aquí la CA entregada por quien administra Mosquitto si el broker usa una CA privada. No se desactiva la validación del certificado.',
                  style: TextStyle(fontSize: 12),
                ),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('Cancelar'),
          ),
          FilledButton(
            onPressed: () {
              Navigator.pop(
                dialogContext,
                CloudSettings(
                  host: hostController.text.trim(),
                  username: usernameController.text.trim(),
                  password: passwordController.text,
                  caPem: caController.text.trim(),
                ),
              );
            },
            child: const Text('Guardar'),
          ),
        ],
      ),
    );

    hostController.dispose();
    usernameController.dispose();
    passwordController.dispose();
    caController.dispose();

    if (settings == null || !mounted) return;

    try {
      await widget.cloudSettingsStore.save(settings);
      if (!mounted) return;
      setState(() => _cloudSettings = settings);
      _showMessage('Configuración MQTT guardada en almacenamiento seguro.');
    } catch (error) {
      _showMessage('No se pudo guardar la configuración: $error', isError: true);
    }
  }

  Future<void> _clearCloudSettings() async {
    await widget.cloudSettingsStore.clear();
    if (!mounted) return;
    setState(() => _cloudSettings = null);
    _showMessage('Se eliminaron las credenciales MQTT guardadas.');
  }

  Future<void> _uploadPendingEvents() async {
    final settings = _cloudSettings;
    final deviceId = _cloudDeviceId;

    if (settings == null || !settings.isComplete) {
      _showMessage('Primero configura el broker MQTT.', isError: true);
      return;
    }
    if (deviceId == null) {
      _showMessage('Todavía no hay eventos BLE con device_id.', isError: true);
      return;
    }
    if (_isUploading) return;

    setState(() {
      _isUploading = true;
      _operationError = null;
      _operationMessage = 'Enviando eventos pendientes a Cloud…';
    });

    try {
      final count = await _cloudSync.upload(
        widget.eventStore,
        settings,
        deviceId,
      );
      await _refreshLocalData();
      if (!mounted) return;
      setState(() {
        _operationMessage =
            'Cloud confirmó el almacenamiento de $count evento(s).';
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _operationError = error.toString();
        _operationMessage =
            'La carga no terminó. Los eventos sin ACK siguen pendientes en SQLite.';
      });
    } finally {
      if (mounted) setState(() => _isUploading = false);
    }
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          backgroundColor: isError ? Theme.of(context).colorScheme.error : null,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _buildDashboard(),
      _buildHistory(),
      _buildDeviceAndCloud(),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Estación TUI'),
        actions: [
          IconButton(
            tooltip: 'Actualizar datos locales',
            onPressed: _refreshLocalData,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            if (_operationMessage != null || _operationError != null)
              _buildOperationBanner(),
            Expanded(child: IndexedStack(index: _selectedPage, children: pages)),
          ],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedPage,
        onDestinationSelected: (index) {
          setState(() => _selectedPage = index);
          if (index == 1) _refreshLocalData();
        },
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.dashboard_outlined),
            selectedIcon: Icon(Icons.dashboard),
            label: 'Resumen',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long),
            label: 'Historial',
          ),
          NavigationDestination(
            icon: Icon(Icons.devices_other_outlined),
            selectedIcon: Icon(Icons.devices_other),
            label: 'Dispositivo',
          ),
        ],
      ),
    );
  }

  Widget _buildOperationBanner() {
    final isError = _operationError != null;
    final text = _operationError ?? _operationMessage ?? '';
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isError ? Colors.red.shade50 : Colors.teal.shade50,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            isError ? Icons.error_outline : Icons.info_outline,
            color: isError ? Colors.red.shade800 : Colors.teal.shade800,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                color: isError ? Colors.red.shade900 : Colors.teal.shade900,
                fontSize: 13,
              ),
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            onPressed: () => setState(() {
              _operationMessage = null;
              _operationError = null;
            }),
            icon: const Icon(Icons.close, size: 18),
          ),
        ],
      ),
    );
  }

  Widget _buildDashboard() {
    final latest = _events.isEmpty ? null : _events.first;
    final batteryMv = latest?['battery_mv'];

    return RefreshIndicator(
      onRefresh: _refreshLocalData,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text(
            'Panel de seguimiento',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
          ),
          const SizedBox(height: 4),
          Text(
            'Registros descargados desde el ESP32 DevKit y estado de sincronización.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: 2,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            childAspectRatio: 1.65,
            children: [
              _StatCard(
                title: 'Eventos locales',
                value: '${_stats['total'] ?? 0}',
                icon: Icons.storage_outlined,
              ),
              _StatCard(
                title: 'Pendientes Cloud',
                value: '${_stats['pending'] ?? 0}',
                icon: Icons.cloud_upload_outlined,
              ),
              _StatCard(
                title: 'Confirmados',
                value: '${_stats['synced'] ?? 0}',
                icon: Icons.cloud_done_outlined,
              ),
              _StatCard(
                title: 'Dispositivos',
                value: '${_deviceIds.length}',
                icon: Icons.memory_outlined,
              ),
            ],
          ),
          const SizedBox(height: 16),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Último registro recibido',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 10),
                  if (latest == null)
                    const Text('Todavía no hay registros. Conecta el ESP32 por BLE.'),
                  if (latest != null) ...[
                    Text('ID: ${latest['event_id'] ?? 'No disponible'}'),
                    Text('Estado: ${_statusLabel(latest['status'])}'),
                    Text('Raíz: ${latest['root']}  ·  Sufijo: ${latest['suffix']}'),
                    if (batteryMv is num)
                      Text(
                        'Tensión reportada: ${(batteryMv / 1000).toStringAsFixed(2)} V',
                      ),
                    const SizedBox(height: 4),
                    Text(
                      latest['_synced'] == true
                          ? 'Sincronización: confirmada por Cloud'
                          : 'Sincronización: pendiente',
                      style: TextStyle(
                        color: latest['_synced'] == true
                            ? Colors.green.shade800
                            : Colors.orange.shade900,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.info_outline),
                  SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      'La lectura de tensión es un dato del divisor ADC y no equivale a un porcentaje calibrado de batería. Esta aplicación no recibe vídeo ni ejecuta la inferencia TinyML; ambas funciones permanecen en las placas.',
                      style: TextStyle(fontSize: 13),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHistory() {
    return RefreshIndicator(
      onRefresh: _refreshLocalData,
      child: _events.isEmpty
          ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(24),
              children: const [
                SizedBox(height: 80),
                Icon(Icons.inbox_outlined, size: 56, color: Colors.grey),
                SizedBox(height: 12),
                Center(child: Text('No hay eventos almacenados todavía.')),
                Center(child: Text('Descarga los registros desde la pestaña Dispositivo.')),
              ],
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _events.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final event = _events[index];
                final synced = event['_synced'] == true;
                return Card(
                  child: ListTile(
                    leading: CircleAvatar(
                      backgroundColor: synced
                          ? Colors.green.shade50
                          : Colors.orange.shade50,
                      child: Icon(
                        synced ? Icons.cloud_done : Icons.pending_actions,
                        color: synced ? Colors.green.shade800 : Colors.orange.shade900,
                      ),
                    ),
                    title: Text(_statusLabel(event['status'])),
                    subtitle: Text(
                      'ID: ${event['event_id']}\n'
                      'Raíz ${event['root']} · Sufijo ${event['suffix']} · '
                      'Equipo ${event['device_id']}',
                    ),
                    isThreeLine: true,
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => _showEventDetails(event),
                  ),
                );
              },
            ),
    );
  }

  Widget _buildDeviceAndCloud() {
    final busy = _isScanning || _isSyncingBle || _isUploading;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Text(
          'Conexión con la estación',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Bluetooth LE',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                const Text(
                  'Busca el servicio de la Estación TUI. La descarga solicita los registros JSONL almacenados en SPIFFS; no transmite imágenes ni vídeo.',
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: OutlinedButton.icon(
                        onPressed: busy ? null : _scanDevices,
                        icon: _isScanning
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.bluetooth_searching),
                        label: Text(_isScanning ? 'Buscando…' : 'Buscar dispositivo'),
                      ),
                    ),
                  ],
                ),
                if (_scanResults.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  const Text(
                    'Dispositivos encontrados',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  for (final result in _scanResults)
                    RadioListTile<String>(
                      contentPadding: EdgeInsets.zero,
                      value: result.device.remoteId.str,
                      groupValue: _selectedDevice?.device.remoteId.str,
                      onChanged: busy
                          ? null
                          : (_) => setState(() => _selectedDevice = result),
                      title: Text(_deviceName(result)),
                      subtitle: Text(
                        '${result.device.remoteId.str}  ·  RSSI ${result.rssi} dBm',
                      ),
                    ),
                ],
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton.icon(
                    onPressed: (_selectedDevice == null || busy)
                        ? null
                        : _syncSelectedDevice,
                    icon: _isSyncingBle
                        ? const SizedBox(
                            width: 16,
                            height: 16,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.download),
                    label: Text(
                      _isSyncingBle ? 'Descargando registros…' : 'Descargar registros BLE',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          'Sincronización Cloud',
          style: Theme.of(context).textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
        ),
        const SizedBox(height: 8),
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(
                      _cloudSettings == null
                          ? Icons.cloud_off_outlined
                          : Icons.cloud_done_outlined,
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        _cloudSettings == null
                            ? 'Broker no configurado'
                            : 'Broker configurado: ${_cloudSettings!.host}',
                        style: const TextStyle(fontWeight: FontWeight.w600),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                const Text(
                  'Los registros se publican por MQTT/TLS en QoS 1. SQLite solo los marca como sincronizados cuando el ingestor devuelve stored=true para el event_id.',
                ),
                const SizedBox(height: 12),
                OutlinedButton.icon(
                  onPressed: busy ? null : _configureCloud,
                  icon: const Icon(Icons.settings_ethernet),
                  label: Text(
                    _cloudSettings == null ? 'Configurar MQTT' : 'Editar configuración MQTT',
                  ),
                ),
                if (_cloudSettings != null) ...[
                  const SizedBox(height: 12),
                  if (_deviceIds.isEmpty)
                    const Text('Descarga primero los eventos BLE para conocer el device_id.'),
                  if (_deviceIds.isNotEmpty) ...[
                    DropdownButtonFormField<String>(
                      value: _cloudDeviceId,
                      decoration: const InputDecoration(
                        labelText: 'Identificador del ESP32',
                        border: OutlineInputBorder(),
                      ),
                      items: _deviceIds
                          .map((id) => DropdownMenuItem(value: id, child: Text(id)))
                          .toList(),
                      onChanged: busy ? null : (value) => setState(() => _cloudDeviceId = value),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: busy ? null : _uploadPendingEvents,
                        icon: _isUploading
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.cloud_upload_outlined),
                        label: Text(
                          _isUploading ? 'Sincronizando…' : 'Enviar pendientes a Cloud',
                        ),
                      ),
                    ),
                  ],
                  TextButton.icon(
                    onPressed: busy ? null : _clearCloudSettings,
                    icon: const Icon(Icons.delete_outline),
                    label: const Text('Eliminar credenciales guardadas'),
                  ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        const Card(
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Text(
              'La ruta pedagógica continúa funcionando en el ESP32 sin Internet. El teléfono actúa como pasarela de registros BLE y sincroniza con Cloud cuando hay red.',
              style: TextStyle(fontSize: 13),
            ),
          ),
        ),
      ],
    );
  }

  String _deviceName(ScanResult result) {
    final advertisedName = result.advertisementData.advName.trim();
    if (advertisedName.isNotEmpty) return advertisedName;
    final platformName = result.device.platformName.trim();
    return platformName.isNotEmpty ? platformName : 'Estación TUI sin nombre';
  }

  String _statusLabel(Object? status) {
    switch (status) {
      case 'valid':
        return 'Combinación válida';
      case 'audio_error':
        return 'Error de audio';
      case 'invalid_combination':
        return 'Combinación no definida';
      case 'recognition_error':
        return 'Error de reconocimiento';
      case 'removed_during_capture':
        return 'Ficha retirada durante captura';
      case 'camera_timeout':
        return 'Tiempo agotado de cámara';
      default:
        return 'Estado no identificado';
    }
  }

  void _showEventDetails(Map<String, dynamic> event) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (context) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'Detalle del evento',
                  style: Theme.of(context).textTheme.titleLarge,
                ),
                const SizedBox(height: 12),
                for (final entry in event.entries)
                  if (!entry.key.startsWith('_'))
                    Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Text('${entry.key}: ${entry.value}'),
                    ),
                const SizedBox(height: 8),
                Text(
                  event['_synced'] == true
                      ? 'Cloud: confirmado'
                      : 'Cloud: pendiente',
                  style: const TextStyle(fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  const _StatCard({
    required this.title,
    required this.value,
    required this.icon,
  });

  final String title;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Icon(icon, color: Theme.of(context).colorScheme.primary),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
            ),
            Text(title, style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ),
    );
  }
}
